package net.minecraft.world.item.trading;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.npc.villager.VillagerType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.Sum;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.commons.lang3.tuple.Triple;

public class TradeRebalanceVillagerTrades {
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_desert_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_jungle_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_plains_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_savanna_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_snow_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_swamp_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_1_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/1/emerald_and_book_taiga_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_desert_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_jungle_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_plains_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_savanna_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_snow_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_swamp_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_2_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/2/emerald_and_book_taiga_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_desert_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_jungle_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_plains_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_savanna_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_snow_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_swamp_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_3_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/3/emerald_and_book_taiga_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_desert_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_jungle_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_plains_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_savanna_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_snow_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_swamp_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> LIBRARIAN_5_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK = VillagerTrades.resourceKey(
		"librarian/5/emerald_and_book_taiga_enchanted_book"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_1_IRON_INGOT_EMERALD = VillagerTrades.resourceKey("armorer/1/iron_ingot_emerald");
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_IRON_BOOTS_GROUP_1 = VillagerTrades.resourceKey("armorer/2/emerald_iron_boots_group_1");
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_IRON_HELMET_GROUP_1 = VillagerTrades.resourceKey("armorer/2/emerald_iron_helmet_group_1");
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_IRON_LEGGINGS_GROUP_1 = VillagerTrades.resourceKey("armorer/2/emerald_iron_leggings_group_1");
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_IRON_CHESTPLATE_GROUP_1 = VillagerTrades.resourceKey(
		"armorer/2/emerald_iron_chestplate_group_1"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_CHAINMAIL_BOOTS_GROUP_2 = VillagerTrades.resourceKey(
		"armorer/2/emerald_chainmail_boots_group_2"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_CHAINMAIL_HELMET_GROUP_2 = VillagerTrades.resourceKey(
		"armorer/2/emerald_chainmail_helmet_group_2"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_CHAINMAIL_LEGGINGS_GROUP_2 = VillagerTrades.resourceKey(
		"armorer/2/emerald_chainmail_leggings_group_2"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_2_EMERALD_CHAINMAIL_CHESTPLATE_GROUP_2 = VillagerTrades.resourceKey(
		"armorer/2/emerald_chainmail_chainmail_group_2"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_3_EMERALD_BELL = VillagerTrades.resourceKey("armorer/3/emerald_bell");
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_DESERT = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_boots_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_DESERT = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_helmet_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_DESERT = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_leggings_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_DESERT = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_chestplate_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_PLAINS = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_boots_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_PLAINS = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_helmet_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_PLAINS = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_leggings_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_PLAINS = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_chestplate_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_SAVANNA = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_boots_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_SAVANNA = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_helmet_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_SAVANNA = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_leggings_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_SAVANNA = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_chestplate_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_SNOW = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_boots_snow"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_SNOW = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_iron_helmet_snow"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_BOOTS_JUNGLE = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_boots_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_HELMET_JUNGLE = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_helmet_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_LEGGINGS_JUNGLE = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_leggings_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_CHESTPLATE_JUNGLE = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_chestplate_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_BOOTS_SWAMP = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_boots_swamp"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_HELMET_SWAMP = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_helmet_swamp"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_LEGGINGS_SWAMP = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_leggings_swamp"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_CHESTPLATE_SWAMP = VillagerTrades.resourceKey(
		"armorer/4/emerald_enchanted_chainmail_chestplate_swamp"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_AND_DIAMOND_BOOTS_DIAMOND_LEGGINGS_TAIGA = VillagerTrades.resourceKey(
		"armorer/4/emerald_and_diamond_boots_diamond_leggings_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_AND_DIAMOND_LEGGINGS_DIAMOND_CHESTPLATE_TAIGA = VillagerTrades.resourceKey(
		"armorer/4/emerald_and_diamond_leggings_diamond_chestplate_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_AND_DIAMOND_HELMET_DIAMOND_BOOTS_TAIGA = VillagerTrades.resourceKey(
		"armorer/4/emerald_and_diamond_helmet_diamond_boots_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_4_EMERALD_AND_DIAMOND_CHESTPLATE_DIAMOND_HELMET_TAIGA = VillagerTrades.resourceKey(
		"armorer/4/emerald_and_diamond_chestplate_diamond_helmet_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_DESERT = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_chestplate_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_DESERT = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_leggings_desert"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_PLAINS = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_leggings_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_BOOTS_PLAINS = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_boots_plains"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_HELMET_SAVANNA = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_helmet_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_SAVANNA = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_chestplate_savanna"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_BOOTS_SNOW = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_boots_snow"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_HELMET_SNOW = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_helmet_snow"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_CHAINMAIL_HELMET_JUNGLE = VillagerTrades.resourceKey(
		"armorer/5/emerald_chainmail_helmet_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_CHAINMAIL_BOOTS_JUNGLE = VillagerTrades.resourceKey(
		"armorer/5/emerald_chainmail_boots_jungle"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_CHAINMAIL_HELMET_SWAMP = VillagerTrades.resourceKey(
		"armorer/5/emerald_chainmail_helmet_swamp"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_CHAINMAIL_BOOTS_SWAMP = VillagerTrades.resourceKey("armorer/5/emerald_chainmail_boots_swamp");
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_TAIGA = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_chestplate_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_TAIGA = VillagerTrades.resourceKey(
		"armorer/5/emerald_and_diamond_diamond_leggings_taiga"
	);
	public static final ResourceKey<VillagerTrade> ARMORER_5_DIAMOND_BLOCK_EMERALD_TAIGA = VillagerTrades.resourceKey("armorer/5/diamond_block_emerald_taiga");
	public static final ResourceKey<VillagerTrade> ARMORER_5_IRON_BLOCK_EMERALD_NON_TAIGA = VillagerTrades.resourceKey("armorer/5/iron_block_emerald_non_taiga");

	public static Holder<VillagerTrade> bootstrap(final BootstrapContext<VillagerTrade> context) {
		HolderGetter<Item> items = context.lookup(Registries.ITEM);
		HolderGetter<Enchantment> enchantments = context.lookup(Registries.ENCHANTMENT);
		HolderGetter<VillagerType> villagerVariants = context.lookup(Registries.VILLAGER_TYPE);
		Optional<HolderSet<Enchantment>> doubleTradePrice = context.lookup(Registries.ENCHANTMENT).get(EnchantmentTags.DOUBLE_TRADE_PRICE).map(named -> named);

		for (ImmutableTriple<ResourceKey<VillagerTrade>, ResourceKey<VillagerType>, TagKey<Enchantment>> entry : List.of(
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK, VillagerType.DESERT, EnchantmentTags.TRADES_DESERT_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK, VillagerType.JUNGLE, EnchantmentTags.TRADES_JUNGLE_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK, VillagerType.PLAINS, EnchantmentTags.TRADES_PLAINS_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK, VillagerType.SAVANNA, EnchantmentTags.TRADES_SAVANNA_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK, VillagerType.SNOW, EnchantmentTags.TRADES_SNOW_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK, VillagerType.SWAMP, EnchantmentTags.TRADES_SWAMP_COMMON),
			ImmutableTriple.of(LIBRARIAN_1_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK, VillagerType.TAIGA, EnchantmentTags.TRADES_TAIGA_COMMON)
		)) {
			VillagerTrades.register(
				context,
				entry.getLeft(),
				new VillagerTrade(
					new TradeCost(Items.EMERALD, 0),
					Optional.of(new TradeCost(Items.BOOK, 1)),
					new ItemStackTemplate(Items.ENCHANTED_BOOK),
					12,
					1,
					0.2F,
					VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, entry.getMiddle())),
					VillagerTrades.enchantedBook(items, enchantments.get(entry.getRight()).map(named1 -> named1)),
					doubleTradePrice
				)
			);
		}

		VillagerTrades.register(
			context,
			VillagerTrades.LIBRARIAN_2_BOOK_EMERALD,
			new VillagerTrade(new TradeCost(Items.BOOK, 4), new ItemStackTemplate(Items.EMERALD), 12, 10, 0.05F, Optional.empty(), List.of())
		);

		for (ImmutableTriple<ResourceKey<VillagerTrade>, ResourceKey<VillagerType>, TagKey<Enchantment>> entry : List.of(
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK, VillagerType.DESERT, EnchantmentTags.TRADES_DESERT_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK, VillagerType.JUNGLE, EnchantmentTags.TRADES_JUNGLE_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK, VillagerType.PLAINS, EnchantmentTags.TRADES_PLAINS_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK, VillagerType.SAVANNA, EnchantmentTags.TRADES_SAVANNA_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK, VillagerType.SNOW, EnchantmentTags.TRADES_SNOW_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK, VillagerType.SWAMP, EnchantmentTags.TRADES_SWAMP_COMMON),
			ImmutableTriple.of(LIBRARIAN_2_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK, VillagerType.TAIGA, EnchantmentTags.TRADES_TAIGA_COMMON)
		)) {
			VillagerTrades.register(
				context,
				entry.getLeft(),
				new VillagerTrade(
					new TradeCost(Items.EMERALD, 0),
					Optional.of(new TradeCost(Items.BOOK, 1)),
					new ItemStackTemplate(Items.ENCHANTED_BOOK),
					12,
					5,
					0.2F,
					VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, entry.getMiddle())),
					VillagerTrades.enchantedBook(items, enchantments.get(entry.getRight()).map(named1 -> named1)),
					doubleTradePrice
				)
			);
		}

		for (ImmutableTriple<ResourceKey<VillagerTrade>, ResourceKey<VillagerType>, TagKey<Enchantment>> entry : List.of(
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK, VillagerType.DESERT, EnchantmentTags.TRADES_DESERT_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK, VillagerType.JUNGLE, EnchantmentTags.TRADES_JUNGLE_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK, VillagerType.PLAINS, EnchantmentTags.TRADES_PLAINS_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK, VillagerType.SAVANNA, EnchantmentTags.TRADES_SAVANNA_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK, VillagerType.SNOW, EnchantmentTags.TRADES_SNOW_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK, VillagerType.SWAMP, EnchantmentTags.TRADES_SWAMP_COMMON),
			ImmutableTriple.of(LIBRARIAN_3_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK, VillagerType.TAIGA, EnchantmentTags.TRADES_TAIGA_COMMON)
		)) {
			VillagerTrades.register(
				context,
				entry.getLeft(),
				new VillagerTrade(
					new TradeCost(Items.EMERALD, 0),
					Optional.of(new TradeCost(Items.BOOK, 1)),
					new ItemStackTemplate(Items.ENCHANTED_BOOK),
					12,
					10,
					0.2F,
					VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, entry.getMiddle())),
					VillagerTrades.enchantedBook(items, enchantments.get(entry.getRight()).map(named1 -> named1)),
					doubleTradePrice
				)
			);
		}

		for (TradeRebalanceVillagerTrades.BookTradeDefinition entry : List.of(
			new TradeRebalanceVillagerTrades.BookTradeDefinition(LIBRARIAN_5_EMERALD_AND_BOOK_DESERT_ENCHANTED_BOOK, VillagerType.DESERT, Enchantments.EFFICIENCY, 3),
			new TradeRebalanceVillagerTrades.BookTradeDefinition(LIBRARIAN_5_EMERALD_AND_BOOK_JUNGLE_ENCHANTED_BOOK, VillagerType.JUNGLE, Enchantments.UNBREAKING, 2),
			new TradeRebalanceVillagerTrades.BookTradeDefinition(LIBRARIAN_5_EMERALD_AND_BOOK_PLAINS_ENCHANTED_BOOK, VillagerType.PLAINS, Enchantments.PROTECTION, 3),
			new TradeRebalanceVillagerTrades.BookTradeDefinition(LIBRARIAN_5_EMERALD_AND_BOOK_SAVANNA_ENCHANTED_BOOK, VillagerType.SAVANNA, Enchantments.SHARPNESS, 3),
			new TradeRebalanceVillagerTrades.BookTradeDefinition(LIBRARIAN_5_EMERALD_AND_BOOK_TAIGA_ENCHANTED_BOOK, VillagerType.TAIGA, Enchantments.FORTUNE, 2)
		)) {
			int level = entry.level;
			Holder.Reference<Enchantment> enchantment = enchantments.getOrThrow(entry.enchantment);
			VillagerTrades.register(
				context,
				entry.resourceKey(),
				new VillagerTrade(
					new TradeCost(Items.EMERALD, Sum.sum(ConstantValue.exactly(3 * level + 2), UniformGenerator.between(0.0F, 5 + level * 10))),
					Optional.of(new TradeCost(Items.BOOK, 1)),
					new ItemStackTemplate(Items.ENCHANTED_BOOK),
					12,
					30,
					0.2F,
					VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, entry.villagerType())),
					VillagerTrades.enchantedBook(items, enchantment, level),
					doubleTradePrice
				)
			);
		}

		for (Triple<ResourceKey<VillagerTrade>, ResourceKey<VillagerType>, ResourceKey<Enchantment>> entry : List.of(
			Triple.of(LIBRARIAN_5_EMERALD_AND_BOOK_SNOW_ENCHANTED_BOOK, VillagerType.SNOW, Enchantments.SILK_TOUCH),
			Triple.of(LIBRARIAN_5_EMERALD_AND_BOOK_SWAMP_ENCHANTED_BOOK, VillagerType.SWAMP, Enchantments.MENDING)
		)) {
			VillagerTrades.register(
				context,
				entry.getLeft(),
				new VillagerTrade(
					new TradeCost(Items.EMERALD, 0),
					Optional.of(new TradeCost(Items.BOOK, 1)),
					new ItemStackTemplate(Items.ENCHANTED_BOOK),
					12,
					30,
					0.2F,
					VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, entry.getMiddle())),
					VillagerTrades.enchantedBook(items, Optional.of(HolderSet.direct(enchantments.getOrThrow(entry.getRight())))),
					doubleTradePrice
				)
			);
		}

		VillagerTrades.register(
			context,
			ARMORER_1_IRON_INGOT_EMERALD,
			new VillagerTrade(
				new TradeCost(Items.IRON_INGOT, 5),
				new ItemStackTemplate(Items.EMERALD),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.TAIGA)
					)
				),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_IRON_BOOTS_GROUP_1,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 4),
				new ItemStackTemplate(Items.IRON_BOOTS),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.TAIGA)
					)
				),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_IRON_HELMET_GROUP_1,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 5),
				new ItemStackTemplate(Items.IRON_HELMET),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.TAIGA)
					)
				),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_IRON_LEGGINGS_GROUP_1,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 7),
				new ItemStackTemplate(Items.IRON_LEGGINGS),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.TAIGA)
					)
				),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_IRON_CHESTPLATE_GROUP_1,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.IRON_CHESTPLATE),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.TAIGA)
					)
				),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_CHAINMAIL_BOOTS_GROUP_2,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 4),
				new ItemStackTemplate(Items.CHAINMAIL_BOOTS),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE, VillagerType.SWAMP))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_CHAINMAIL_HELMET_GROUP_2,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 5),
				new ItemStackTemplate(Items.CHAINMAIL_HELMET),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE, VillagerType.SWAMP))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_CHAINMAIL_LEGGINGS_GROUP_2,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 7),
				new ItemStackTemplate(Items.CHAINMAIL_LEGGINGS),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE, VillagerType.SWAMP))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_2_EMERALD_CHAINMAIL_CHESTPLATE_GROUP_2,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.CHAINMAIL_CHESTPLATE),
				12,
				5,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE, VillagerType.SWAMP))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_3_EMERALD_BELL,
			new VillagerTrade(new TradeCost(Items.EMERALD, 36), new ItemStackTemplate(Items.BELL), 12, 10, 0.2F, Optional.empty(), List.of())
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.IRON_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.IRON_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.IRON_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.IRON_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 11),
				new ItemStackTemplate(Items.IRON_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.IRON_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 13),
				new ItemStackTemplate(Items.IRON_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.IRON_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.IRON_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.IRON_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.IRON_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.IRON_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 11),
				new ItemStackTemplate(Items.IRON_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.IRON_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 13),
				new ItemStackTemplate(Items.IRON_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.IRON_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 2),
				new ItemStackTemplate(Items.IRON_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.IRON_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 3),
				new ItemStackTemplate(Items.IRON_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.IRON_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_LEGGINGS_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 5),
				new ItemStackTemplate(Items.IRON_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.IRON_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_CHESTPLATE_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 7),
				new ItemStackTemplate(Items.IRON_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.IRON_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_BOOTS_SNOW,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.IRON_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SNOW))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.FROST_WALKER), 1, Items.IRON_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_IRON_HELMET_SNOW,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.IRON_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SNOW))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.AQUA_AFFINITY), 1, Items.IRON_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_BOOTS_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.CHAINMAIL_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.UNBREAKING), 1, Items.CHAINMAIL_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_HELMET_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.CHAINMAIL_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.UNBREAKING), 1, Items.CHAINMAIL_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_LEGGINGS_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 11),
				new ItemStackTemplate(Items.CHAINMAIL_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.UNBREAKING), 1, Items.CHAINMAIL_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_CHESTPLATE_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 13),
				new ItemStackTemplate(Items.CHAINMAIL_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.UNBREAKING), 1, Items.CHAINMAIL_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_BOOTS_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.CHAINMAIL_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.MENDING), 1, Items.CHAINMAIL_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_HELMET_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.CHAINMAIL_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.MENDING), 1, Items.CHAINMAIL_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_LEGGINGS_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 11),
				new ItemStackTemplate(Items.CHAINMAIL_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.MENDING), 1, Items.CHAINMAIL_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_ENCHANTED_CHAINMAIL_CHESTPLATE_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 13),
				new ItemStackTemplate(Items.CHAINMAIL_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.MENDING), 1, Items.CHAINMAIL_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_AND_DIAMOND_BOOTS_DIAMOND_LEGGINGS_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 4),
				Optional.of(new TradeCost(Items.DIAMOND_BOOTS, 1)),
				new ItemStackTemplate(Items.DIAMOND_LEGGINGS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_AND_DIAMOND_LEGGINGS_DIAMOND_CHESTPLATE_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 4),
				Optional.of(new TradeCost(Items.DIAMOND_LEGGINGS, 1)),
				new ItemStackTemplate(Items.DIAMOND_CHESTPLATE),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_AND_DIAMOND_HELMET_DIAMOND_BOOTS_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 4),
				Optional.of(new TradeCost(Items.DIAMOND_HELMET, 1)),
				new ItemStackTemplate(Items.DIAMOND_BOOTS),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_4_EMERALD_AND_DIAMOND_CHESTPLATE_DIAMOND_HELMET_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 2),
				Optional.of(new TradeCost(Items.DIAMOND_CHESTPLATE, 1)),
				new ItemStackTemplate(Items.DIAMOND_HELMET),
				3,
				15,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				List.of()
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 16),
				Optional.of(new TradeCost(Items.DIAMOND, 4)),
				new ItemStackTemplate(Items.DIAMOND_CHESTPLATE),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.DIAMOND_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_DESERT,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 16),
				Optional.of(new TradeCost(Items.DIAMOND, 3)),
				new ItemStackTemplate(Items.DIAMOND_LEGGINGS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.DESERT))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.THORNS), 1, Items.DIAMOND_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 16),
				Optional.of(new TradeCost(Items.DIAMOND, 3)),
				new ItemStackTemplate(Items.DIAMOND_LEGGINGS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.DIAMOND_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_BOOTS_PLAINS,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 12),
				Optional.of(new TradeCost(Items.DIAMOND, 2)),
				new ItemStackTemplate(Items.DIAMOND_BOOTS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.PLAINS))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROTECTION), 1, Items.DIAMOND_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_HELMET_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 6),
				Optional.of(new TradeCost(Items.DIAMOND, 2)),
				new ItemStackTemplate(Items.DIAMOND_HELMET),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.DIAMOND_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_SAVANNA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				Optional.of(new TradeCost(Items.DIAMOND, 3)),
				new ItemStackTemplate(Items.DIAMOND_CHESTPLATE),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SAVANNA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BINDING_CURSE), 1, Items.DIAMOND_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_BOOTS_SNOW,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 12),
				Optional.of(new TradeCost(Items.DIAMOND, 2)),
				new ItemStackTemplate(Items.DIAMOND_BOOTS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SNOW))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.FROST_WALKER), 1, Items.DIAMOND_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_HELMET_SNOW,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 12),
				Optional.of(new TradeCost(Items.DIAMOND, 3)),
				new ItemStackTemplate(Items.DIAMOND_HELMET),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SNOW))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.AQUA_AFFINITY), 1, Items.DIAMOND_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_CHAINMAIL_HELMET_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.CHAINMAIL_HELMET),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.PROJECTILE_PROTECTION), 1, Items.CHAINMAIL_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_CHAINMAIL_BOOTS_JUNGLE,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.CHAINMAIL_BOOTS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.JUNGLE))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.FEATHER_FALLING), 1, Items.CHAINMAIL_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_CHAINMAIL_HELMET_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 9),
				new ItemStackTemplate(Items.CHAINMAIL_HELMET),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.RESPIRATION), 1, Items.CHAINMAIL_HELMET)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_CHAINMAIL_BOOTS_SWAMP,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 8),
				new ItemStackTemplate(Items.CHAINMAIL_BOOTS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.SWAMP))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.DEPTH_STRIDER), 1, Items.CHAINMAIL_BOOTS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_CHESTPLATE_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 18),
				Optional.of(new TradeCost(Items.DIAMOND, 4)),
				new ItemStackTemplate(Items.DIAMOND_CHESTPLATE),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BLAST_PROTECTION), 1, Items.DIAMOND_CHESTPLATE)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_EMERALD_AND_DIAMOND_DIAMOND_LEGGINGS_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.EMERALD, 18),
				Optional.of(new TradeCost(Items.DIAMOND, 3)),
				new ItemStackTemplate(Items.DIAMOND_LEGGINGS),
				3,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				VillagerTrades.enchantedItem(items, enchantments.getOrThrow(Enchantments.BLAST_PROTECTION), 1, Items.DIAMOND_LEGGINGS)
			)
		);
		VillagerTrades.register(
			context,
			ARMORER_5_DIAMOND_BLOCK_EMERALD_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.DIAMOND_BLOCK, 1),
				new ItemStackTemplate(Items.EMERALD, 42),
				12,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(VillagerTrades.villagerTypeHolderSet(villagerVariants, List.of(VillagerType.TAIGA))),
				List.of()
			)
		);
		return VillagerTrades.register(
			context,
			ARMORER_5_IRON_BLOCK_EMERALD_NON_TAIGA,
			new VillagerTrade(
				new TradeCost(Items.IRON_BLOCK, 1),
				new ItemStackTemplate(Items.EMERALD, 4),
				12,
				30,
				0.05F,
				VillagerTrades.villagerTypeRestriction(
					VillagerTrades.villagerTypeHolderSet(
						villagerVariants, List.of(VillagerType.DESERT, VillagerType.JUNGLE, VillagerType.PLAINS, VillagerType.SAVANNA, VillagerType.SNOW, VillagerType.SWAMP)
					)
				),
				List.of()
			)
		);
	}

	private record BookTradeDefinition(
		ResourceKey<VillagerTrade> resourceKey, ResourceKey<VillagerType> villagerType, ResourceKey<Enchantment> enchantment, int level
	) {
	}
}
