package net.minecraft.world.item.alchemy;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class Potions {
	public static final Holder.Reference<Potion> WATER = register("water", new Potion("water"));
	public static final Holder.Reference<Potion> MUNDANE = register("mundane", new Potion("mundane"));
	public static final Holder.Reference<Potion> THICK = register("thick", new Potion("thick"));
	public static final Holder.Reference<Potion> AWKWARD = register("awkward", new Potion("awkward"));
	public static final Holder.Reference<Potion> NIGHT_VISION = register(
		"night_vision", new Potion("night_vision", new MobEffectInstance(MobEffects.NIGHT_VISION, 3600))
	);
	public static final Holder.Reference<Potion> LONG_NIGHT_VISION = register(
		"long_night_vision", new Potion("night_vision", new MobEffectInstance(MobEffects.NIGHT_VISION, 9600))
	);
	public static final Holder.Reference<Potion> INVISIBILITY = register(
		"invisibility", new Potion("invisibility", new MobEffectInstance(MobEffects.INVISIBILITY, 3600))
	);
	public static final Holder.Reference<Potion> LONG_INVISIBILITY = register(
		"long_invisibility", new Potion("invisibility", new MobEffectInstance(MobEffects.INVISIBILITY, 9600))
	);
	public static final Holder.Reference<Potion> LEAPING = register("leaping", new Potion("leaping", new MobEffectInstance(MobEffects.JUMP_BOOST, 3600)));
	public static final Holder.Reference<Potion> LONG_LEAPING = register("long_leaping", new Potion("leaping", new MobEffectInstance(MobEffects.JUMP_BOOST, 9600)));
	public static final Holder.Reference<Potion> STRONG_LEAPING = register(
		"strong_leaping", new Potion("leaping", new MobEffectInstance(MobEffects.JUMP_BOOST, 1800, 1))
	);
	public static final Holder.Reference<Potion> FIRE_RESISTANCE = register(
		"fire_resistance", new Potion("fire_resistance", new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 3600))
	);
	public static final Holder.Reference<Potion> LONG_FIRE_RESISTANCE = register(
		"long_fire_resistance", new Potion("fire_resistance", new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 9600))
	);
	public static final Holder.Reference<Potion> SWIFTNESS = register("swiftness", new Potion("swiftness", new MobEffectInstance(MobEffects.SPEED, 3600)));
	public static final Holder.Reference<Potion> LONG_SWIFTNESS = register(
		"long_swiftness", new Potion("swiftness", new MobEffectInstance(MobEffects.SPEED, 9600))
	);
	public static final Holder.Reference<Potion> STRONG_SWIFTNESS = register(
		"strong_swiftness", new Potion("swiftness", new MobEffectInstance(MobEffects.SPEED, 1800, 1))
	);
	public static final Holder.Reference<Potion> SLOWNESS = register("slowness", new Potion("slowness", new MobEffectInstance(MobEffects.SLOWNESS, 1800)));
	public static final Holder.Reference<Potion> LONG_SLOWNESS = register(
		"long_slowness", new Potion("slowness", new MobEffectInstance(MobEffects.SLOWNESS, 4800))
	);
	public static final Holder.Reference<Potion> STRONG_SLOWNESS = register(
		"strong_slowness", new Potion("slowness", new MobEffectInstance(MobEffects.SLOWNESS, 400, 3))
	);
	public static final Holder.Reference<Potion> TURTLE_MASTER = register(
		"turtle_master", new Potion("turtle_master", new MobEffectInstance(MobEffects.SLOWNESS, 400, 3), new MobEffectInstance(MobEffects.RESISTANCE, 400, 2))
	);
	public static final Holder.Reference<Potion> LONG_TURTLE_MASTER = register(
		"long_turtle_master", new Potion("turtle_master", new MobEffectInstance(MobEffects.SLOWNESS, 800, 3), new MobEffectInstance(MobEffects.RESISTANCE, 800, 2))
	);
	public static final Holder.Reference<Potion> STRONG_TURTLE_MASTER = register(
		"strong_turtle_master", new Potion("turtle_master", new MobEffectInstance(MobEffects.SLOWNESS, 400, 5), new MobEffectInstance(MobEffects.RESISTANCE, 400, 3))
	);
	public static final Holder.Reference<Potion> WATER_BREATHING = register(
		"water_breathing", new Potion("water_breathing", new MobEffectInstance(MobEffects.WATER_BREATHING, 3600))
	);
	public static final Holder.Reference<Potion> LONG_WATER_BREATHING = register(
		"long_water_breathing", new Potion("water_breathing", new MobEffectInstance(MobEffects.WATER_BREATHING, 9600))
	);
	public static final Holder.Reference<Potion> HEALING = register("healing", new Potion("healing", new MobEffectInstance(MobEffects.INSTANT_HEALTH, 1)));
	public static final Holder.Reference<Potion> STRONG_HEALING = register(
		"strong_healing", new Potion("healing", new MobEffectInstance(MobEffects.INSTANT_HEALTH, 1, 1))
	);
	public static final Holder.Reference<Potion> HARMING = register("harming", new Potion("harming", new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1)));
	public static final Holder.Reference<Potion> STRONG_HARMING = register(
		"strong_harming", new Potion("harming", new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 1))
	);
	public static final Holder.Reference<Potion> POISON = register("poison", new Potion("poison", new MobEffectInstance(MobEffects.POISON, 900)));
	public static final Holder.Reference<Potion> LONG_POISON = register("long_poison", new Potion("poison", new MobEffectInstance(MobEffects.POISON, 1800)));
	public static final Holder.Reference<Potion> STRONG_POISON = register("strong_poison", new Potion("poison", new MobEffectInstance(MobEffects.POISON, 432, 1)));
	public static final Holder.Reference<Potion> REGENERATION = register(
		"regeneration", new Potion("regeneration", new MobEffectInstance(MobEffects.REGENERATION, 900))
	);
	public static final Holder.Reference<Potion> LONG_REGENERATION = register(
		"long_regeneration", new Potion("regeneration", new MobEffectInstance(MobEffects.REGENERATION, 1800))
	);
	public static final Holder.Reference<Potion> STRONG_REGENERATION = register(
		"strong_regeneration", new Potion("regeneration", new MobEffectInstance(MobEffects.REGENERATION, 450, 1))
	);
	public static final Holder.Reference<Potion> STRENGTH = register("strength", new Potion("strength", new MobEffectInstance(MobEffects.STRENGTH, 3600)));
	public static final Holder.Reference<Potion> LONG_STRENGTH = register(
		"long_strength", new Potion("strength", new MobEffectInstance(MobEffects.STRENGTH, 9600))
	);
	public static final Holder.Reference<Potion> STRONG_STRENGTH = register(
		"strong_strength", new Potion("strength", new MobEffectInstance(MobEffects.STRENGTH, 1800, 1))
	);
	public static final Holder.Reference<Potion> WEAKNESS = register("weakness", new Potion("weakness", new MobEffectInstance(MobEffects.WEAKNESS, 1800)));
	public static final Holder.Reference<Potion> LONG_WEAKNESS = register(
		"long_weakness", new Potion("weakness", new MobEffectInstance(MobEffects.WEAKNESS, 4800))
	);
	public static final Holder.Reference<Potion> LUCK = register("luck", new Potion("luck", new MobEffectInstance(MobEffects.LUCK, 6000)));
	public static final Holder.Reference<Potion> SLOW_FALLING = register(
		"slow_falling", new Potion("slow_falling", new MobEffectInstance(MobEffects.SLOW_FALLING, 1800))
	);
	public static final Holder.Reference<Potion> LONG_SLOW_FALLING = register(
		"long_slow_falling", new Potion("slow_falling", new MobEffectInstance(MobEffects.SLOW_FALLING, 4800))
	);
	public static final Holder.Reference<Potion> WIND_CHARGED = register(
		"wind_charged", new Potion("wind_charged", new MobEffectInstance(MobEffects.WIND_CHARGED, 3600))
	);
	public static final Holder.Reference<Potion> WEAVING = register("weaving", new Potion("weaving", new MobEffectInstance(MobEffects.WEAVING, 3600)));
	public static final Holder.Reference<Potion> OOZING = register("oozing", new Potion("oozing", new MobEffectInstance(MobEffects.OOZING, 3600)));
	public static final Holder.Reference<Potion> INFESTED = register("infested", new Potion("infested", new MobEffectInstance(MobEffects.INFESTED, 3600)));

	private static Holder.Reference<Potion> register(final String name, final Potion potion) {
		return Registry.registerForHolder(BuiltInRegistries.POTION, Identifier.withDefaultNamespace(name), potion);
	}

	public static Holder.Reference<Potion> bootstrap(final Registry<Potion> registry) {
		return WATER;
	}
}
